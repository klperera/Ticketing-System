import { Component, OnInit } from '@angular/core';
import { User } from '../app-classes/User/user';
import { ActivatedRoute, Router } from '@angular/router';
import { OrganizerNavBarComponent } from '../NavBar/organizer-nav-bar/organizer-nav-bar.component';
import { UserServiceService } from '../Service/user-service.service';

@Component({
  selector: 'app-check-event-details',
  standalone: true,
  imports: [OrganizerNavBarComponent],
  templateUrl: './check-event-details.component.html',
  styleUrl: './check-event-details.component.css'
})
export class CheckEventDetailsComponent implements OnInit {

  logedInUser: any = {};
  user: User = new User();

  constructor(private activeRoute: ActivatedRoute, private userService: UserServiceService, private router: Router) { }

  ngOnInit(): void {
    this.activeRoute.paramMap.subscribe(params => {
      this.user.usertype = params.get('usertype') || 'user';
    });
    this.logedInUser = history.state;
    this.user = this.logedInUser.userCredentials;
    this.user.usertype = this.logedInUser.usertype;
    console.log(this.user);
    this.userService.user_method(this.user, 'checkevents').subscribe(
      (details) => {
        console.log(`${this.logedInUser.usertype}`+" - Data passed.");
        if (details.message === "All events have been found.") {
          alert(details.message);
          console.log(details.object);
          this.router.navigateByUrl(`${this.logedInUser.usertype}/home`, {state: this.logedInUser});
        }else{
          alert(details.message);
        }
      },
      (error) =>{
        console.log(`${this.logedInUser.usertype}`+" - Error.");
      }
    );
  } 
}
