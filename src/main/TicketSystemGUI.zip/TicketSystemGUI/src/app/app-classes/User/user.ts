export class User {

    email: string = "";
    username: string = "";
    password: string = "";
    usertype: string = "";

    
}
